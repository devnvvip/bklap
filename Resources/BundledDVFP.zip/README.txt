Dynamic Vehicle First Person
============================

A custom first person vehicle camera script, with inertia effects,
dynamic horizon lock, depth of field effects and a lot of customizability.

Originally made within Manual Transmission as a fix for locked camera with
synced wheel animations, but it got too big.

For in-depth information about the script, check Docs/README-Advanced.pdf
For a full changelog, check Docs/Changelog.pdf

Requirements
============

Grand Theft Auto V
ScriptHookV

Installation
============

Copy the following files and folders to the GTA V folder:

* `DynamicVehicleFirstPerson.asi`
* `DynamicVehicleFirstPerson` (folder)

Alternative:

The `DynamicVehicleFirstPerson` folder can also be put in `%localappdata%\ikt\`.
This is useful if the GTA V folder isn't accessible/writeable for the script,
or you want to share the same setup between FiveM and SP.
(For FiveM installation, just copy `DynamicVehicleFirstPerson.asi` to the FiveM
plugins folder).

Menu opening/Usage
==================

Use cheat `dfpv` to open the menu.

The cheat, hotkey or controller shortcut may also be changed in
the `settings_menu.ini` file. `_info_Keys_Controls.txt` lists usable keys.

For FiveM, the cheat console is not available.
Please assign any hotkey to open the menu.

All camera settings are adjusted within the menu, with descriptions for
what each option does.

Credits
=======

* CamxCore for usage of DismembermentASI.asi throughout the years, thanks!
* C0RSAIR for the tip to hide the player head natively, thanks!


Redistribution
==============

This archive is ONLY uploaded to the following location:

GTA5-Mods.com: https://www.gta5-mods.com/scripts/dynamic-vehicle-first-person

REDISTRIBUTION OF THIS ARCHIVE IS NOT ALLOWED
MODIFICATION OF THIS ARCHIVE IS NOT ALLOWED

(C) ikt 2026
